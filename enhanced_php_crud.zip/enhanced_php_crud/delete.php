<?php
include __DIR__ . '/db.php';

$id = $_GET['id'];
$stmt = $db->prepare("DELETE FROM users WHERE id = ?");
$stmt->execute([$id]);
header("Location: index.php");
exit;
