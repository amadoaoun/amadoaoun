<?php
// unauthorized.php
?>

<!DOCTYPE html>
<html>
<head><title>Unauthorized</title></head>
<body>
<h1>Access Denied</h1>
<p>You do not have permission to access this page.</p>
<a href="index.php">Go back to home</a>
</body>
</html>