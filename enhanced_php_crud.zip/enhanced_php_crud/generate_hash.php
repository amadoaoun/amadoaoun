<?php
// Replace YourNewPasswordHere with your desired new password
echo password_hash('amado', PASSWORD_DEFAULT);
?>